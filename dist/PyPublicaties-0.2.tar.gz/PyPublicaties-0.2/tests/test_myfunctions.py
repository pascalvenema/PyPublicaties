from PyPublicaties import myfunctions

